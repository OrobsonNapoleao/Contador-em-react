import { useState } from 'react'
import './App.css'

function App() {
  const [value, setValue] = useState(0)

  return (
    <>
    <div className='contador'>
      <h1>contador simples em React</h1>
      <h2>{value}</h2>
      <button className='btn' onClick={() => setValue(value + 1) }>
      aumentar 1
      </button>
      <button className='btn' onClick={() => setValue(value - 1) }>
      diminuir 1
      </button>
      <button className='btn' onClick={() => setValue(0) }>
      resetar 
      </button>
    </div>

    </>
     
  )
}

export default App
